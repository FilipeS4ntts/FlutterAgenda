package com.example.flutterqmagico

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
