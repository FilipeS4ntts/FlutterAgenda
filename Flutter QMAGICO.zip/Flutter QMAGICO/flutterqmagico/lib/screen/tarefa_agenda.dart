import 'package:flutter/material.dart';

class TarefaAgenda extends StatefulWidget {
  const TarefaAgenda({super.key});

  @override
  State<TarefaAgenda> createState() => _TarefaAgendaState();
}

class _TarefaAgendaState extends State<TarefaAgenda> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _tarefaController = TextEditingController();
  List<String> tarefas = [];

  void _adicionarTarefa() {
    if (_formKey.currentState!.validate()) {
      setState(() {
        tarefas.add(_tarefaController.text);
        _tarefaController.clear();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tarefa Agenda'),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Form(
              key: _formKey,
              child: TextFormField(
                controller: _tarefaController,
                decoration: InputDecoration(
                  labelText: 'Digite a Tarefa',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, digite uma tarefa';
                  }
                  return null;
                },
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: _adicionarTarefa,
              icon: Icon(Icons.add),
              label: Text('Adicionar'),
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.white,
                backgroundColor: Colors.deepPurple,
              ),
            ),
            SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: tarefas.length,
                itemBuilder: (context, index) {
                  return Card(
                    color: Colors.deepPurple[50],
                    margin: EdgeInsets.symmetric(vertical: 8),
                    child: ListTile(
                      leading: Icon(Icons.check_circle_outline, color: Colors.deepPurple),
                      title: Text(
                        tarefas[index],
                        style: TextStyle(fontSize: 18),
                      ),
                      trailing: IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          setState(() {
                            tarefas.removeAt(index);
                          });
                        },
                      ),
                    ),
                  );
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}