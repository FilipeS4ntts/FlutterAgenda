
import 'package:flutter/material.dart';


class CounterPage extends StatefulWidget { 
  const CounterPage({super.key});

  @override
  State<CounterPage> createState() => _CounterPageState();
}

class _CounterPageState extends State<CounterPage> {
  onPressed() {
   Navigator.pushNamed(context, '/tarefa');
}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Atividade Qmágico')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
         children: [
       const Text('Ir Para a Página Tarefa Agenda',
       style: TextStyle(
      color: Colors.white,
       fontSize: 45, 
    ),
  ),
 ElevatedButton(onPressed: onPressed, child: Column(
  children: [Text("Vamo ali ó")],
 ))
],
        ),
      ),
     
    );
  }
}
