import 'package:flutter/material.dart';
import 'package:flutterqmagico/screen/counter_page.dart';
import 'package:flutterqmagico/screen/tarefa_agenda.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primaryColor: Colors.deepPurpleAccent,
        scaffoldBackgroundColor: const Color.fromARGB(255, 223, 191, 191),
        //vou optar por nao mudar a cor dos textos para nao quebrar o design
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => CounterPage(),
        '/tarefa': (context) => TarefaAgenda(),
      },
    );
  }
}